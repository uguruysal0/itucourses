For corner detecion - 
run q1.py
For segmentation -
run q2.py
